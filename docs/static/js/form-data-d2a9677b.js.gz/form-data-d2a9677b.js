var o=typeof self=="object"?self.FormData:window.FormData;const a=o;export{a as F};
